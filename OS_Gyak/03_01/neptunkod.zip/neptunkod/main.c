#include <stdio.h>

int main ()
{
   FILE * fp;
   int i;

   fp = fopen ("D:\\vezeteknev.txt","w");
   fprintf (fp, "Barta_Agoston\nGazdasaginformatikus\nBUPLZ8\n");

return 0;
}
